---
permalink: /pt/tutoriais/pkg/
title: "Programas e outros recursos"
---

**Atenção:** Esta página se encontra em manutenção
(última atualização 13 de agosto de 2022)
{: .notice--danger}


- [LaTeX](/pt/tutoriais/pkg/latex/).
- [GNUplot](/pt/tutoriais/pkg/gnuplot/).
