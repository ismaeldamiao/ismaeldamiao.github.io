---
permalink: /pt/links/
title: "Links"
---

* [Programa de Pós-Graduação em Física (UFAL)](http://www.ufal.edu.br/unidadeacademica/if/pt-br/pos-graduacao/mestrado-doutorado-em-fisica)
* [Google Acadêmico](http://scholar.google.com.br/)
* [Sociedade Brasileira de Física](http://www.sbfisica.org.br/)
* [Periódicos CAPES](http://www.periodicos.capes.gov.br/)
* [FAPEAL](http://www.fapeal.br/)
* [CNPQ](http://www.cnpq.br/)
* [NETLIB (Repositório de algorítmos numéricos)](http://www.netlib.org/)
