---
title: "Publicações"
permalink: /pt/publications/
layout: splash
---

## Artigos

{% bibliography --file works.bib  %}
