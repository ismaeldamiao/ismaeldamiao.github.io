---
permalink: /pt/
title: "Olá mundo"
excerpt: "Católico, monarquista e amante de física"
sidebar: true
header:
  overlay_image: ./images/site.png
---

## Quem sou eu?

**Nome**: Ismael Felipe Ferreira dos Santos  
**Nascimento**: Maceió, Alagoas, Brasil -- 09 de dezembro de 1999  
**Alma Mater**: [Universidade Federal de Alagoas](https://ufal.br/ufal)  
**Orientador**: [Dr. Francisco Fidelis](http://200.17.113.231/~fidelis)  
**Religião**: Católico  
**Política**: [Monarquista](https://monarquia.org.br/)

Futuramente escreverei mais sobre mim,
por hora falta-me inspiração para relatar qualquer fato que possa causar o interesse do meu leitor.

### Currículos (IDs)

[**Lattes**](http://lattes.cnpq.br/1281887099263383)  
[**ResearcherID**](https://publons.com/researcher/4644666/ismael-felipe-ferreira-dos-santos/)  
[**ORCID**](https://orcid.org/0000-0002-6652-9295)  
[**Scorpus ID**](https://www.scopus.com/authid/detail.uri?authorId=22979186900)  
[**Google Acadêmico**](https://scholar.google.com/citations?user=RktjGkgAAAAJ)

### Estatísticas do GitHub

![A name](https://github-readme-stats.vercel.app/api?username=ismaeldamiao&locale=pt-pt&show_icons=true&include_all_commits=true&count_private=true&theme=onedark)
![A name](https://github-readme-stats.vercel.app/api/top-langs/?username=ismaeldamiao&locale=pt-pt&langs_count=7&theme=onedark&layout=compact&exclude_repo=ismaeldamiao.github.io)

### Principais Repositórios

[![A name](https://github-readme-stats.vercel.app/api/pin/?username=ismaeldamiao&locale=pt-pt&theme=onedark&repo=ismaeldamiao.github.io)](https://github.com/ismaeldamiao/ismaeldamiao.github.io)
[![A name](https://github-readme-stats.vercel.app/api/pin/?username=ismaeldamiao&locale=pt-pt&theme=onedark&repo=libismael)](https://github.com/ismaeldamiao/libismael)

