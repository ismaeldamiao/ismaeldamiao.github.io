---
permalink: /pt/blog/categories/
title: "Blog (listado por categoria)"
layout: categories
---

Clique [aqui](/pt/blog/posts/) para ver por data.
