---
permalink: /pt/blog/posts/
title: "Blog (listado por data)"
layout: posts
---

Clique [aqui](/pt/blog/categories/) para ver listado por categorias.
