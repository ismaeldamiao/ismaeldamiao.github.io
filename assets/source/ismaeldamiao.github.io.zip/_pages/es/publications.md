---
title: "Publicaciones"
permalink: /es/publications/
layout: single
classes: wide
author_profile: true
toc: true
toc_label: "Resumen"
toc_icon: "cog"
---


## Artículos

{% bibliography --file works.bib  %}
