---
permalink: /es/
title: ""
excerpt: "Católico, monárquico y me encanta la física"
author_profile: true
sidebar: true
header:
  overlay_image: ./images/site.png
---

Este sitio ha sido hecho para divulgación de mi trabajo, la versión en portugués del sitio cuenta aún con material que quizá pueda interesar a alumnos de graduación en física.

# Ismael Felipe Ferreira dos Santos

**Nacimiento**: Maceió, Alagoas, Brasil 09 de diciembre de 1999

**Alma Mater**: [Universidade Federal de Alagoas](http://www.ufal.edu.br/ufal)

**Tutor**: [Dr. Francisco Fidelis](http://200.17.113.231/~fidelis)

**Religión**: Católico

**Política**: [Monárquico](https://monarquia.org.br/)

### Estadística do GitHub

![A name](https://github-readme-stats.vercel.app/api?username=ismaeldamiao&locale=es&show_icons=true&include_all_commits=true&count_private=true&theme=onedark)
![A name](https://github-readme-stats.vercel.app/api/top-langs/?username=ismaeldamiao&locale=es&langs_count=7&theme=onedark&layout=compact&exclude_repo=ismaeldamiao.github.io)

### Principales Repositórios

[![A name](https://github-readme-stats.vercel.app/api/pin/?username=ismaeldamiao&locale=es&theme=onedark&repo=ismaeldamiao.github.io)](https://github.com/ismaeldamiao/ismaeldamiao.github.io)
[![A name](https://github-readme-stats.vercel.app/api/pin/?username=ismaeldamiao&locale=es&theme=onedark&repo=libismael)](https://github.com/ismaeldamiao/libismael)
