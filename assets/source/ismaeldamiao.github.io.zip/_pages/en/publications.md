---
title: "Publications"
permalink: /en/publications/
layout: single
classes: wide
author_profile: true
toc: true
toc_label: "Table of Contents"
toc_icon: "cog"
---


## Articles

{% bibliography --file works.bib  %}
