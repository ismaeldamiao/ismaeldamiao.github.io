function Show(id1){
   //id1.innerHTML = id2.innerHTML;
   if(id1.style.display === 'none'){
      id1.style.display = 'block';
   }else{
      id1.style.display = 'none';
   }
}
